/*
 * # Safe Store
 *
 * ## Назначение
 * Хранение и управление приватными записями (секретами):
 * нормализация, сортировка, чтение и CRUD-операции.
 *
 * ## Контекст использования
 * - API-роуты `/api/apps/safe` читают и изменяют записи Safe.
 * - Источник истины хранится в SQLite, JSON используется как legacy-снапшот.
 *
 * ## Основные сценарии
 * 1) Загрузить список записей из SQLite и мигрировать legacy JSON.
 * 2) Создать/обновить/удалить запись с валидацией полей.
 * 3) Сохранить запись в SQLite и обновить JSON-снапшоты.
 *
 * ## Модель данных (упрощенно)
 * - Entry: { id, title, category, secret, notes, createdAt, updatedAt }
 *
 * ## I/O и файлы
 * - Основное хранилище: SQLite `data/safe/safe.sqlite`.
 * - Legacy/snapshot: `data/safe/<user>/*.json`.
 *
 * ## Связанная информация
 * - Проект: PromanOS Mini (server)
 * - Связанные файлы: `server/routes/safe.js`, `server/config.js`
 *
 * ## Инварианты и валидация
 * - Требуется title или secret.
 * - ID соответствует `ENTRY_ID_RE`.
 * - Длины полей ограничены `SAFE_CONSTANTS`.
 *
 * ## Версия документа
 * - 2
 */
const fs = require('fs');
const path = require('path');
const { randomUUID } = require('crypto');
const { SAFE_DATA_DIR, SAFE_DB_FILE, SAFE_CONSTANTS } = require('../../../../server/config');
const { writeJSONSecure } = require('../../../../server/storage');
const { createSqliteJsonStore } = require('../../../../server/sqlite-json-store');
const { normalizeUserKey } = require('../../../../apps/users/runtime/server/users');

const {
  MAX_TITLE,
  MAX_CATEGORY,
  MAX_SECRET,
  MAX_NOTES,
  MAX_ENTRIES,
  ENTRY_ID_RE,
  ENTRY_FILE_RE
} = SAFE_CONSTANTS;
const SAFE_DB_PATH = String(SAFE_DB_FILE || path.join(SAFE_DATA_DIR, 'safe.sqlite')).trim()
  || path.join(SAFE_DATA_DIR, 'safe.sqlite');
const safeEntriesStore = createSqliteJsonStore({
  dbPath: SAFE_DB_PATH,
  tableName: 'safe_users',
  keyColumn: 'user_key'
});

let safeQueue = Promise.resolve();

/* Раздел: утилиты и нормализация. */
function sanitizeText(value, limit = 0) {
  const text = value == null ? '' : String(value).trim();
  if (!limit || text.length <= limit) return text;
  return text.slice(0, limit);
}

function normalizeTimestamp(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  const parsed = Date.parse(raw);
  if (!Number.isFinite(parsed)) return '';
  return new Date(parsed).toISOString();
}

function normalizeEntryId(value) {
  const id = String(value || '').trim();
  if (!id) return '';
  return ENTRY_ID_RE && ENTRY_ID_RE.test(id) ? id : '';
}

function normalizeStoredEntry(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const id = normalizeEntryId(raw.id);
  if (!id) return null;
  const title = sanitizeText(raw.title, MAX_TITLE);
  const category = sanitizeText(raw.category, MAX_CATEGORY);
  const secret = sanitizeText(raw.secret, MAX_SECRET);
  const notes = sanitizeText(raw.notes, MAX_NOTES);
  if (!title && !secret) return null;
  const createdAt = normalizeTimestamp(raw.createdAt) || new Date().toISOString();
  const updatedAt = normalizeTimestamp(raw.updatedAt) || createdAt;
  return {
    id,
    title,
    category,
    secret,
    notes,
    createdAt,
    updatedAt
  };
}

function sortEntries(entries) {
  return entries.sort((a, b) => {
    const aTime = Date.parse(a.updatedAt || a.createdAt || '') || 0;
    const bTime = Date.parse(b.updatedAt || b.createdAt || '') || 0;
    return bTime - aTime;
  });
}

function withSafeLock(task) {
  const run = safeQueue.then(task, task);
  safeQueue = run.catch(() => {});
  return run;
}

/* Раздел: вычисление путей. */
function getSafeDir(username) {
  const key = normalizeUserKey(username);
  if (!key) return '';
  return path.join(SAFE_DATA_DIR, key);
}

function getSafeStoreKey(username) {
  return normalizeUserKey(username);
}

async function ensureSafeDir(dir) {
  if (!dir) return;
  try {
    await fs.promises.mkdir(dir, { recursive: true, mode: 0o700 });
  } catch (err) {
    if (err?.code !== 'EEXIST') throw err;
  }
  try {
    await fs.promises.chmod(dir, 0o700);
  } catch {
    // игнорируем ошибки chmod
  }
}

async function listEntryFiles(dir) {
  if (!dir) return [];
  try {
    const entries = await fs.promises.readdir(dir);
    return entries.filter((name) => (ENTRY_FILE_RE ? ENTRY_FILE_RE.test(name) : name.endsWith('.json')));
  } catch (err) {
    if (err?.code !== 'ENOENT') {
      console.warn('[mini] failed to read safe entries:', err?.message || err);
    }
    return [];
  }
}

async function readEntryFile(filePath) {
  try {
    const raw = await fs.promises.readFile(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    return normalizeStoredEntry(parsed);
  } catch (err) {
    if (err?.code !== 'ENOENT') {
      console.warn('[mini] failed to read safe entry:', err?.message || err);
    }
    return null;
  }
}

/* Раздел: операции чтения. */
function normalizeEntriesList(rawEntries) {
  const entries = Array.isArray(rawEntries)
    ? rawEntries.map(normalizeStoredEntry).filter(Boolean)
    : [];
  const sorted = sortEntries(entries);
  if (MAX_ENTRIES && MAX_ENTRIES > 0) {
    return sorted.slice(0, MAX_ENTRIES);
  }
  return sorted;
}

function readEntriesFromStore(username) {
  const storeKey = getSafeStoreKey(username);
  if (!storeKey) return { found: false, entries: [] };
  try {
    const fromDb = safeEntriesStore.readEntry(storeKey);
    if (!fromDb.found) return { found: false, entries: [] };
    if (fromDb.malformed) {
      console.warn('[mini] safe: malformed sqlite payload');
      return { found: false, entries: [] };
    }
    const payload = fromDb.payload && typeof fromDb.payload === 'object' ? fromDb.payload : {};
    return {
      found: true,
      entries: normalizeEntriesList(payload.entries)
    };
  } catch (err) {
    console.warn('[mini] safe: failed to read sqlite entries:', err?.message || err);
    return { found: false, entries: [] };
  }
}

async function loadLegacyEntries(username) {
  const dir = getSafeDir(username);
  if (!dir) return [];
  const files = await listEntryFiles(dir);
  const entries = [];
  for (const name of files) {
    const entry = await readEntryFile(path.join(dir, name));
    if (entry) entries.push(entry);
  }
  return normalizeEntriesList(entries);
}

async function loadSafeEntries(username) {
  const fromStore = readEntriesFromStore(username);
  if (fromStore.found) return fromStore.entries;
  const legacyEntries = await loadLegacyEntries(username);
  const storeKey = getSafeStoreKey(username);
  if (storeKey) {
    try {
      safeEntriesStore.writeEntry(storeKey, {
        entries: legacyEntries,
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      console.warn('[mini] safe: failed to migrate legacy entries to sqlite:', err?.message || err);
    }
  }
  return legacyEntries;
}

async function syncLegacyEntries(username, entries) {
  const dir = getSafeDir(username);
  if (!dir) return;
  await ensureSafeDir(dir);
  const normalized = normalizeEntriesList(entries);
  const expected = new Set();
  for (const entry of normalized) {
    const fileName = `${entry.id}.json`;
    expected.add(fileName);
    await writeJSONSecure(path.join(dir, fileName), entry);
  }
  const existing = await listEntryFiles(dir);
  for (const fileName of existing) {
    if (expected.has(fileName)) continue;
    try {
      await fs.promises.unlink(path.join(dir, fileName));
    } catch (err) {
      if (err?.code !== 'ENOENT') {
        console.warn('[mini] failed to delete stale safe entry snapshot:', err?.message || err);
      }
    }
  }
}

async function persistSafeEntries(username, entries) {
  const storeKey = getSafeStoreKey(username);
  if (!storeKey) throw new Error('SAFE_USER_REQUIRED');
  const normalized = normalizeEntriesList(entries);
  try {
    safeEntriesStore.writeEntry(storeKey, {
      entries: normalized,
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.warn('[mini] safe: failed to persist sqlite entries:', err?.message || err);
    throw err;
  }
  await syncLegacyEntries(username, normalized);
  return normalized;
}

async function listSafeEntries(username) {
  return loadSafeEntries(username);
}

/* Раздел: операции записи. */
function buildNewEntry(payload) {
  const title = sanitizeText(payload?.title, MAX_TITLE);
  const category = sanitizeText(payload?.category, MAX_CATEGORY);
  const secret = sanitizeText(payload?.secret, MAX_SECRET);
  const notes = sanitizeText(payload?.notes, MAX_NOTES);
  if (!title && !secret) return null;
  const now = new Date().toISOString();
  return {
    id: randomUUID(),
    title,
    category,
    secret,
    notes,
    createdAt: now,
    updatedAt: now
  };
}

function applyEntryUpdate(existing, payload) {
  if (!existing) return null;
  const next = { ...existing };
  if (payload && Object.prototype.hasOwnProperty.call(payload, 'title')) {
    next.title = sanitizeText(payload.title, MAX_TITLE);
  }
  if (payload && Object.prototype.hasOwnProperty.call(payload, 'category')) {
    next.category = sanitizeText(payload.category, MAX_CATEGORY);
  }
  if (payload && Object.prototype.hasOwnProperty.call(payload, 'secret')) {
    next.secret = sanitizeText(payload.secret, MAX_SECRET);
  }
  if (payload && Object.prototype.hasOwnProperty.call(payload, 'notes')) {
    next.notes = sanitizeText(payload.notes, MAX_NOTES);
  }
  if (!next.title && !next.secret) return null;
  next.updatedAt = new Date().toISOString();
  return next;
}

async function addSafeEntry(username, payload) {
  return withSafeLock(async () => {
    const entry = buildNewEntry(payload);
    if (!entry) return { status: 'invalid' };
    const entries = await loadSafeEntries(username);
    if (MAX_ENTRIES && entries.length >= MAX_ENTRIES) return { status: 'limit' };
    const nextEntries = [entry, ...entries.filter((item) => item.id !== entry.id)];
    const persisted = await persistSafeEntries(username, nextEntries);
    const saved = persisted.find((item) => item.id === entry.id) || entry;
    return { status: 'ok', entry: saved };
  });
}

async function updateSafeEntry(username, id, payload) {
  return withSafeLock(async () => {
    const entryId = normalizeEntryId(id);
    if (!entryId) return { status: 'missing' };
    const entries = await loadSafeEntries(username);
    const existing = entries.find((item) => item.id === entryId);
    if (!existing) return { status: 'missing' };
    const updated = applyEntryUpdate(existing, payload);
    if (!updated) return { status: 'invalid' };
    const nextEntries = entries.map((item) => (item.id === entryId ? updated : item));
    const persisted = await persistSafeEntries(username, nextEntries);
    const saved = persisted.find((item) => item.id === entryId) || updated;
    return { status: 'ok', entry: saved };
  });
}

async function deleteSafeEntry(username, id) {
  return withSafeLock(async () => {
    const entryId = normalizeEntryId(id);
    if (!entryId) return false;
    const entries = await loadSafeEntries(username);
    const nextEntries = entries.filter((item) => item.id !== entryId);
    if (nextEntries.length === entries.length) return false;
    await persistSafeEntries(username, nextEntries);
    return true;
  });
}

module.exports = {
  listSafeEntries,
  addSafeEntry,
  updateSafeEntry,
  deleteSafeEntry
};
