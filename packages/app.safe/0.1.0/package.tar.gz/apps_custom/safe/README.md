# Safe

Placeholder for Safe app metadata.

- Client: public/apps/safe/
- OpenAPI: apps/safe/openapi.js
- Server routes: server/routes/safe.js
