/*
 * # OpenAPI: Safe
 *
 * ## Назначение
 * OpenAPI-описание CRUD API приложения Safe.
 *
 * ## Контекст использования
 * - Возвращается маршрутом `/api/apps/safe/openapi`.
 * - Требует активную сессию пользователя.
 *
 * ## Модель данных (кратко)
 * - Entry: { id, title, category, secret, notes, createdAt, updatedAt }.
 *
 * ## I/O и файлы
 * - Использует `server/openapi-utils.js`.
 *
 * ## Инварианты и валидация
 * - Для создания/обновления требуется title или secret.
 *
 * ## Версия документа
 * - 1
 */
const { applySessionSecurity, applyBaseUrl } = require('../../server/openapi-utils');

/* Раздел: схемы данных Safe. */
function buildSafeSchemas() {
  return {
    safeEntry: {
      type: 'object',
      additionalProperties: false,
      required: ['id'],
      properties: {
        id: { type: 'string' },
        title: { type: 'string' },
        category: { type: 'string' },
        secret: { type: 'string' },
        notes: { type: 'string' },
        createdAt: { type: 'string', format: 'date-time' },
        updatedAt: { type: 'string', format: 'date-time' }
      }
    },
    safeListResponse: {
      type: 'object',
      additionalProperties: false,
      required: ['ok', 'entries'],
      properties: {
        ok: { type: 'boolean' },
        entries: { type: 'array', items: { $ref: '#/components/schemas/safeEntry' } }
      }
    },
    safeEntryResponse: {
      type: 'object',
      additionalProperties: false,
      required: ['ok', 'entry'],
      properties: {
        ok: { type: 'boolean' },
        entry: { $ref: '#/components/schemas/safeEntry' }
      }
    },
    safeCreate: {
      type: 'object',
      additionalProperties: false,
      properties: {
        title: { type: 'string' },
        category: { type: 'string' },
        secret: { type: 'string' },
        notes: { type: 'string' }
      },
      anyOf: [{ required: ['title'] }, { required: ['secret'] }]
    },
    safeUpdate: {
      type: 'object',
      additionalProperties: false,
      properties: {
        title: { type: 'string' },
        category: { type: 'string' },
        secret: { type: 'string' },
        notes: { type: 'string' }
      },
      anyOf: [
        { required: ['title'] },
        { required: ['category'] },
        { required: ['secret'] },
        { required: ['notes'] }
      ]
    },
    okResponse: {
      type: 'object',
      additionalProperties: false,
      required: ['ok'],
      properties: { ok: { type: 'boolean' } }
    },
    errorResponse: {
      type: 'object',
      additionalProperties: true,
      required: ['code', 'message'],
      properties: {
        code: { type: 'string' },
        message: { type: 'string' }
      }
    }
  };
}

/* Раздел: сборка OpenAPI документа. */
function buildSafeOpenApi({ baseUrl } = {}) {
  const schemas = buildSafeSchemas();
  const document = {
    openapi: '3.1.0',
    info: {
      title: 'Safe API',
      version: '1',
      description: 'CRUD endpoints for PromanOS Mini Safe app.'
    },
    tags: [{ name: 'safe', description: 'Safe secrets endpoints.' }],
    paths: {
      '/api/apps/safe': {
        get: {
          tags: ['safe'],
          summary: 'List safe entries.',
          responses: {
            200: {
              description: 'OK',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/safeListResponse' } }
              }
            }
          }
        },
        post: {
          tags: ['safe'],
          summary: 'Create safe entry.',
          requestBody: {
            required: true,
            content: {
              'application/json': { schema: { $ref: '#/components/schemas/safeCreate' } }
            }
          },
          responses: {
            201: {
              description: 'Created',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/safeEntryResponse' } }
              }
            },
            400: {
              description: 'Bad Request',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/errorResponse' } }
              }
            },
            409: {
              description: 'Conflict',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/errorResponse' } }
              }
            }
          }
        }
      },
      '/api/apps/safe/{id}': {
        put: {
          tags: ['safe'],
          summary: 'Update safe entry.',
          parameters: [
            { name: 'id', in: 'path', required: true, schema: { type: 'string' } }
          ],
          requestBody: {
            required: true,
            content: {
              'application/json': { schema: { $ref: '#/components/schemas/safeUpdate' } }
            }
          },
          responses: {
            200: {
              description: 'OK',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/safeEntryResponse' } }
              }
            },
            400: {
              description: 'Bad Request',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/errorResponse' } }
              }
            },
            404: {
              description: 'Not Found',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/errorResponse' } }
              }
            }
          }
        },
        delete: {
          tags: ['safe'],
          summary: 'Delete safe entry.',
          parameters: [
            { name: 'id', in: 'path', required: true, schema: { type: 'string' } }
          ],
          responses: {
            200: {
              description: 'OK',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/okResponse' } }
              }
            },
            404: {
              description: 'Not Found',
              content: {
                'application/json': { schema: { $ref: '#/components/schemas/errorResponse' } }
              }
            }
          }
        }
      }
    },
    components: {
      schemas
    }
  };
  applyBaseUrl(document, baseUrl);
  applySessionSecurity(document);
  return document;
}

module.exports = {
  buildSafeOpenApi
};
