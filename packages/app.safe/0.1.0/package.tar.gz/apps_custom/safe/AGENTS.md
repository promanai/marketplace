# AGENTS

## Context
- App for safe workflows in Mini.

## Entry Points
- Server: apps/safe/runtime/server/safe.js
- Client: public/apps/safe/index.html, public/apps/safe/app.js, public/apps/safe/styles.css
- OpenAPI: apps/safe/openapi.js
- Routes: server/routes/safe.js

## Data & Storage
- Persistent data (if any) lives under data/safe/ or app-specific stores defined in server runtime.

## Do
- Use i18n for UI text and keep `data-i18n` updated.
- Keep files under ~25k tokens when possible.
- Prefer server-backed storage.

## Don't
- Don't add UI logic in `public/app.js`.
- Don't use `localStorage` for app data unless requested.
- Don't put app assets outside `public/apps/safe/`.

## Tests
- Manual: open the app UI (if any), exercise the primary flow, reload.
