import {
  DEFAULT_LANGUAGE,
  LANG_KEY,
  SAFE_API,
  SAFE_MAX_CATEGORY,
  SAFE_MAX_NOTES,
  SAFE_MAX_SECRET,
  SAFE_MAX_TITLE,
  SUPPORTED_LANGUAGES,
  THEME_KEY
} from '../../js/config.js';
import { TRANSLATIONS } from '../../js/translations.js';
import { baseLangTag, getBrowserLanguages } from '../../js/locale.js';
import { apiRequest } from '../../js/api.js';

const dom = {
  list: document.getElementById('safeList'),
  empty: document.getElementById('emptyState'),
  listMeta: document.getElementById('listMeta'),
  statTotal: document.getElementById('statTotal'),
  statUpdated: document.getElementById('statUpdated'),
  search: document.getElementById('searchInput'),
  form: document.getElementById('safeForm'),
  formTitle: document.getElementById('formTitle'),
  formStatus: document.getElementById('formStatus'),
  title: document.getElementById('entryTitle'),
  category: document.getElementById('entryCategory'),
  secret: document.getElementById('entrySecret'),
  notes: document.getElementById('entryNotes'),
  save: document.getElementById('entrySave'),
  cancel: document.getElementById('entryCancel'),
  clear: document.getElementById('clearForm'),
  newEntry: document.getElementById('newEntry'),
  refresh: document.getElementById('refreshEntries'),
  tabButtons: Array.from(document.querySelectorAll('[data-safe-tab]')),
  tabPanels: Array.from(document.querySelectorAll('[data-safe-panel]'))
};

const i18n = { lang: DEFAULT_LANGUAGE };
const state = {
  entries: [],
  search: '',
  editingId: '',
  isLoading: false,
  isSaving: false,
  activeTab: 'vault',
  reveal: new Set(),
  status: {
    message: '',
    kind: ''
  },
  statusTimer: null
};

const TAB_ORDER = ['vault', 'new'];

function resolveTranslation(locale, key) {
  if (!locale || !key) return null;
  const root = TRANSLATIONS[locale];
  if (!root) return null;
  return key.split('.').reduce((acc, part) => {
    if (!acc || typeof acc !== 'object') return null;
    return acc[part];
  }, root);
}

function interpolate(template, vars) {
  if (!template || !vars) return template || '';
  return template.replace(/\{(\w+)\}/g, (match, token) => {
    if (!Object.prototype.hasOwnProperty.call(vars, token)) return match;
    return String(vars[token]);
  });
}

function t(key, vars) {
  const lang = i18n.lang || DEFAULT_LANGUAGE;
  const value = resolveTranslation(lang, key);
  const fallback = resolveTranslation(DEFAULT_LANGUAGE, key);
  const template = typeof value === 'string' ? value : (typeof fallback === 'string' ? fallback : '');
  if (!template) return key;
  return interpolate(template, vars);
}

function getEmptyLabel() {
  const label = t('mini.safe.labels.empty');
  return label && label !== 'mini.safe.labels.empty' ? label : '--';
}

function getSupportedLanguage(value) {
  const base = baseLangTag(value);
  return SUPPORTED_LANGUAGES.includes(base) ? base : '';
}

function resolveBrowserLanguage() {
  const candidates = getBrowserLanguages();
  for (const candidate of candidates) {
    const supported = getSupportedLanguage(candidate);
    if (supported) return supported;
  }
  return DEFAULT_LANGUAGE;
}

function readLanguage() {
  try {
    const saved = localStorage.getItem(LANG_KEY);
    const supported = getSupportedLanguage(saved);
    if (supported) return supported;
  } catch {
    // ignore
  }
  return resolveBrowserLanguage();
}

function setLanguage(lang) {
  const supported = getSupportedLanguage(lang) || DEFAULT_LANGUAGE;
  i18n.lang = supported;
  applyTranslations();
  render();
}

function applyTranslations() {
  document.documentElement.lang = i18n.lang || DEFAULT_LANGUAGE;
  document.title = t('mini.safe.title');
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.dataset.i18n;
    if (!key) return;
    el.textContent = t(key);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const key = el.dataset.i18nPlaceholder;
    if (!key) return;
    el.setAttribute('placeholder', t(key));
  });
  document.querySelectorAll('[data-i18n-aria-label]').forEach((el) => {
    const key = el.dataset.i18nAriaLabel;
    if (!key) return;
    el.setAttribute('aria-label', t(key));
  });
}

function applyTheme(theme) {
  const resolved = theme === 'dark' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', resolved);
}

function readTheme() {
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch {
    // ignore
  }
  try {
    localStorage.setItem(THEME_KEY, 'dark');
  } catch {
    // ignore
  }
  return 'dark';
}

function readTabFromUrl() {
  try {
    const params = new URLSearchParams(window.location.search);
    const tab = String(params.get('tab') || '').trim();
    if (TAB_ORDER.includes(tab)) return tab;
  } catch {
    // ignore
  }
  return 'vault';
}

function writeTabToUrl(tab) {
  try {
    const url = new URL(window.location.href);
    url.searchParams.set('tab', tab);
    window.history.replaceState({}, '', url.toString());
  } catch {
    // ignore
  }
}

function setActiveTab(tab, { syncUrl = true } = {}) {
  const resolved = TAB_ORDER.includes(tab) ? tab : 'vault';
  state.activeTab = resolved;
  dom.tabButtons.forEach((btn) => {
    const active = btn.dataset.safeTab === resolved;
    btn.classList.toggle('is-active', active);
    btn.setAttribute('aria-selected', active ? 'true' : 'false');
    btn.tabIndex = active ? 0 : -1;
  });
  dom.tabPanels.forEach((panel) => {
    const active = panel.dataset.safePanel === resolved;
    panel.hidden = !active;
  });
  if (syncUrl) writeTabToUrl(resolved);
  if (resolved === 'new' && dom.title) dom.title.focus();
  renderStatus();
}

function formatDate(value) {
  const emptyLabel = getEmptyLabel();
  if (!value) return emptyLabel;
  try {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return emptyLabel;
    return date.toLocaleString(i18n.lang || DEFAULT_LANGUAGE, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return emptyLabel;
  }
}

function maskSecret(value) {
  if (!value) return '';
  const length = Math.max(6, Math.min(12, value.length));
  return '*'.repeat(length);
}

function resetForm() {
  state.editingId = '';
  if (dom.form) dom.form.reset();
  if (dom.category) dom.category.value = '';
  if (dom.secret) dom.secret.value = '';
  if (dom.notes) dom.notes.value = '';
  updateFormHeader();
  setStatus('', '');
}

function fillForm(entry) {
  if (!entry) return;
  state.editingId = entry.id;
  if (dom.title) dom.title.value = entry.title || '';
  if (dom.category) dom.category.value = entry.category || '';
  if (dom.secret) dom.secret.value = entry.secret || '';
  if (dom.notes) dom.notes.value = entry.notes || '';
  updateFormHeader();
}

function updateFormHeader() {
  if (!dom.formTitle || !dom.save || !dom.cancel) return;
  if (state.editingId) {
    dom.formTitle.textContent = t('mini.safe.form.titleEdit');
    dom.save.textContent = t('mini.safe.form.saveEdit');
    dom.cancel.style.display = '';
  } else {
    dom.formTitle.textContent = t('mini.safe.form.titleNew');
    dom.save.textContent = t('mini.safe.form.saveNew');
    dom.cancel.style.display = 'none';
  }
}

function getPayloadFromForm() {
  return {
    title: (dom.title?.value || '').trim(),
    category: (dom.category?.value || '').trim(),
    secret: (dom.secret?.value || '').trim(),
    notes: (dom.notes?.value || '').trim()
  };
}

function setStatus(message, kind = '') {
  if (state.statusTimer) {
    window.clearTimeout(state.statusTimer);
    state.statusTimer = null;
  }
  state.status = { message, kind };
  renderStatus();
  if (message) {
    state.statusTimer = window.setTimeout(() => {
      state.status = { message: '', kind: '' };
      renderStatus();
    }, 2200);
  }
}

function renderStatus() {
  if (!dom.formStatus) return;
  const message = state.status.message;
  dom.formStatus.textContent = message || '';
  dom.formStatus.classList.toggle('is-error', state.status.kind === 'error');
  if (state.activeTab === 'vault') {
    renderListMeta();
  }
}

function renderListMeta() {
  if (!dom.listMeta) return;
  if (state.activeTab === 'vault' && state.status.message) {
    dom.listMeta.textContent = state.status.message;
    return;
  }
  const count = getFilteredEntries().length;
  dom.listMeta.textContent = t('mini.safe.list.count', { count });
}

function getFilteredEntries() {
  const query = state.search.trim().toLowerCase();
  if (!query) return state.entries;
  return state.entries.filter((entry) => {
    const title = (entry.title || '').toLowerCase();
    const category = (entry.category || '').toLowerCase();
    const notes = (entry.notes || '').toLowerCase();
    const secret = (entry.secret || '').toLowerCase();
    return [title, category, notes, secret].some((value) => value.includes(query));
  });
}

function buildCard(entry, index) {
  const card = document.createElement('article');
  card.className = 'safeCard';
  if (entry.id === state.editingId) card.classList.add('is-active');
  card.style.setProperty('--delay', `${Math.min(index * 60, 360)}ms`);

  const title = document.createElement('div');
  title.className = 'cardTitle';
  title.textContent = entry.title || t('mini.safe.form.titleNew');

  const meta = document.createElement('div');
  meta.className = 'cardMeta';
  meta.textContent = t('mini.safe.card.updated', { date: formatDate(entry.updatedAt || entry.createdAt) });

  const category = document.createElement('div');
  category.className = 'cardCategory';
  if (entry.category) {
    category.textContent = `${t('mini.safe.card.categoryLabel')}: ${entry.category}`;
  } else {
    category.style.display = 'none';
  }

  const hasSecret = Boolean(entry.secret);
  const secret = document.createElement('div');
  secret.className = 'cardSecret';
  secret.textContent = state.reveal.has(entry.id) ? (entry.secret || '') : maskSecret(entry.secret || '');
  if (!hasSecret) secret.style.display = 'none';

  const notes = document.createElement('div');
  notes.className = 'cardNotes';
  notes.textContent = entry.notes || '';
  if (!entry.notes) notes.style.display = 'none';

  const actions = document.createElement('div');
  actions.className = 'cardActions';

  const revealBtn = document.createElement('button');
  revealBtn.type = 'button';
  revealBtn.className = 'actionBtn';
  revealBtn.textContent = state.reveal.has(entry.id) ? t('mini.safe.card.hide') : t('mini.safe.card.reveal');
  revealBtn.setAttribute('aria-label', revealBtn.textContent);
  revealBtn.disabled = !hasSecret;
  revealBtn.addEventListener('click', () => {
    if (state.reveal.has(entry.id)) {
      state.reveal.delete(entry.id);
    } else {
      state.reveal.add(entry.id);
    }
    render();
  });

  const copyBtn = document.createElement('button');
  copyBtn.type = 'button';
  copyBtn.className = 'actionBtn';
  copyBtn.textContent = t('mini.safe.card.copy');
  copyBtn.setAttribute('aria-label', t('mini.safe.card.copy'));
  copyBtn.disabled = !hasSecret;
  copyBtn.addEventListener('click', () => handleCopy(entry));

  const editBtn = document.createElement('button');
  editBtn.type = 'button';
  editBtn.className = 'actionBtn';
  editBtn.textContent = t('mini.safe.card.edit');
  editBtn.setAttribute('aria-label', t('mini.safe.card.edit'));
  editBtn.addEventListener('click', () => {
    fillForm(entry);
    setActiveTab('new');
  });

  const deleteBtn = document.createElement('button');
  deleteBtn.type = 'button';
  deleteBtn.className = 'actionBtn danger';
  deleteBtn.textContent = t('mini.safe.card.delete');
  deleteBtn.setAttribute('aria-label', t('mini.safe.card.delete'));
  deleteBtn.addEventListener('click', () => handleDelete(entry));

  actions.append(revealBtn, copyBtn, editBtn, deleteBtn);

  card.append(title, meta, category, secret, notes, actions);
  return card;
}

function renderList() {
  if (!dom.list) return;
  const entries = getFilteredEntries();
  dom.list.innerHTML = '';
  entries.forEach((entry, index) => {
    dom.list.appendChild(buildCard(entry, index));
  });
  if (dom.empty) dom.empty.style.display = entries.length ? 'none' : 'block';
  renderListMeta();
}

function renderStats() {
  if (dom.statTotal) dom.statTotal.textContent = String(state.entries.length);
  const latest = state.entries
    .map((entry) => entry.updatedAt || entry.createdAt || '')
    .filter(Boolean)
    .sort()
    .reverse()[0];
  if (dom.statUpdated) dom.statUpdated.textContent = latest ? formatDate(latest) : '--';
}

function render() {
  renderList();
  renderStats();
  updateFormHeader();
}

async function loadEntries() {
  if (state.isLoading) return;
  state.isLoading = true;
  try {
    const response = await apiRequest(SAFE_API);
    state.entries = Array.isArray(response?.entries) ? response.entries : [];
  } catch (err) {
    console.warn('[mini] failed to load safe entries:', err?.message || err);
    setStatus(t('mini.safe.status.error'), 'error');
  } finally {
    state.isLoading = false;
    render();
  }
}

async function handleSave(event) {
  event.preventDefault();
  if (state.isSaving) return;
  state.isSaving = true;
  const payload = getPayloadFromForm();
  const isEdit = !!state.editingId;
  try {
    if (isEdit) {
      await apiRequest(`${SAFE_API}/${state.editingId}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
    } else {
      await apiRequest(SAFE_API, {
        method: 'POST',
        body: JSON.stringify(payload)
      });
    }
    resetForm();
    await loadEntries();
    setActiveTab('vault');
    setStatus(t('mini.safe.status.saved'));
  } catch (err) {
    console.warn('[mini] failed to save safe entry:', err?.message || err);
    setStatus(t('mini.safe.status.error'), 'error');
  } finally {
    state.isSaving = false;
  }
}

async function handleDelete(entry) {
  if (!entry) return;
  const confirmed = window.confirm(t('mini.safe.confirmDelete'));
  if (!confirmed) return;
  try {
    await apiRequest(`${SAFE_API}/${entry.id}`, { method: 'DELETE' });
    if (state.reveal.has(entry.id)) state.reveal.delete(entry.id);
    setStatus(t('mini.safe.status.deleted'));
    await loadEntries();
  } catch (err) {
    console.warn('[mini] failed to delete safe entry:', err?.message || err);
    setStatus(t('mini.safe.status.error'), 'error');
  }
}

async function handleCopy(entry) {
  if (!entry?.secret) return;
  try {
    await navigator.clipboard.writeText(entry.secret);
    setStatus(t('mini.safe.status.copied'));
  } catch (err) {
    console.warn('[mini] failed to copy safe entry:', err?.message || err);
    setStatus(t('mini.safe.status.error'), 'error');
  }
}

function initTabs() {
  dom.tabButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      setActiveTab(btn.dataset.safeTab);
    });
  });
}

function initActions() {
  if (dom.form) {
    dom.form.addEventListener('submit', handleSave);
  }
  if (dom.cancel) {
    dom.cancel.addEventListener('click', () => {
      resetForm();
      setActiveTab('vault');
    });
  }
  if (dom.clear) {
    dom.clear.addEventListener('click', () => {
      resetForm();
    });
  }
  if (dom.newEntry) {
    dom.newEntry.addEventListener('click', () => {
      resetForm();
      setActiveTab('new');
    });
  }
  if (dom.refresh) {
    dom.refresh.addEventListener('click', () => {
      loadEntries();
    });
  }
  if (dom.search) {
    dom.search.addEventListener('input', () => {
      state.search = dom.search.value || '';
      renderList();
    });
  }
}

function initEmbed() {
  const params = new URLSearchParams(window.location.search);
  if (params.get('embed') === '1') document.body.classList.add('embedded');
}

function initMessaging() {
  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data) return;
    if (data.type === 'theme') applyTheme(data.value);
    if (data.type === 'language') setLanguage(data.value);
    if (data.type === 'embed') document.body.classList.toggle('embedded', !!data.value);
  });

  window.addEventListener('storage', (event) => {
    if (event.key === THEME_KEY) applyTheme(event.newValue);
    if (event.key === LANG_KEY) setLanguage(event.newValue);
  });
}

function applyFieldLimits() {
  if (dom.title) dom.title.maxLength = SAFE_MAX_TITLE;
  if (dom.category) dom.category.maxLength = SAFE_MAX_CATEGORY;
  if (dom.secret) dom.secret.maxLength = SAFE_MAX_SECRET;
  if (dom.notes) dom.notes.maxLength = SAFE_MAX_NOTES;
}

function init() {
  initEmbed();
  applyTheme(readTheme());
  setLanguage(readLanguage());
  applyFieldLimits();
  state.activeTab = readTabFromUrl();
  setActiveTab(state.activeTab, { syncUrl: false });
  initTabs();
  initActions();
  initMessaging();
  loadEntries();
}

init();
